# SUMA - Diseño UML tras la primera auditoría

Revisión del 26 de noviembre de 2026. Se tomó como referencia visual el ejemplo AUTOSYS entregado por el equipo: diagrama general, casos específicos, clases con compartimentos y tarjetas CRC.

El archivo vigente es **SUMA-Diagramas_Vistas.eapx**. Se conserva una copia anterior en `originales/SUMA-Diagramas_Vistas.antes-auditoria-2026-11-26.eapx`.

En Enterprise Architect, abrir **SUMA > Vista de Escenarios > Casos de uso** para las 7 vistas generales, 38 casos específicos y 14 subdetalles. En **SUMA > Vista Lógica > Diagrama Clases** están la vista del núcleo y las 6 vistas complementarias. Se conservaron los IDs CU y los IDs de los diagramas existentes.

El PDF **SUMA-Casos-de-uso-y-clases-Auditoria1.pdf** reúne las 66 vistas, la especificación del flujo automático y las tarjetas CRC de 54 clases e interfaces. El índice de SVG está en `diagramas/Revision-auditoria-1/index.html`.

Los actores permanecen fuera del límite de SUMA. La fuente institucional y el correo son servicios externos. La validación, los reintentos y la base interna son parte del sistema. «include» apunta al comportamiento obligatorio y «extend» al caso base; los resultados automáticos tienen condiciones explícitas.

Las cuentas se validan automáticamente contra datos institucionales autorizados. Ante una falla técnica quedan Pendientes y se reintentan cada 5 minutos. Los referidos se aprueban al cumplir los requisitos; estado, créditos de ambas partes y eventos de notificación se confirman en una transacción. El administrador conserva consulta, configuración, reportes y soporte, sin aprobación manual de cuentas ni referidos.

El diseño conserva los roles configurables mediante Usuario, Rol y Modulo. Los atributos del dominio son privados y las operaciones públicas; se documentan asociaciones, multiplicidades, composición, generalización y realización de la interfaz institucional. Las clases nuevas representan el diseño requerido, sin afirmar que ya estén implementadas.

Verificación: archivo abierto en Enterprise Architect; atributos y operaciones inspeccionados en el editor. Se verificaron referencias e identificadores de las 66 vistas, cobertura de RF-01 a RF-50 (RF-49 transversal), posiciones sin superposición y rutas de clases fuera de las cajas. El PDF se renderizó para revisar distribución y legibilidad.

Los diagramas de secuencia y actividad de aprobación manual afectados están marcados **HISTÓRICO**. Sus reemplazos y las ilustraciones antiguas de Word no forman parte de esta actualización de casos de uso y clases. Los otros archivos EAPX y la carpeta anterior de PNG conservan versiones anteriores; usar el archivo y el índice indicados arriba.
